const LoadersModal = () => {
  return (
    <section className="loader loader--modal" id="loader">
      <div className="loader__spinner loader__spinner--modal"></div>
    </section>
  );
};

export default LoadersModal;