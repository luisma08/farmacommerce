const HomeBestSellers = () => {
  return (
    <h1>HomeBestSellers</h1>
  );
};

export default HomeBestSellers;